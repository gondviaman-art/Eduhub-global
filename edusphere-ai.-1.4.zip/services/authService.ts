import { User } from '../types';

export const registerUser = async (user: Partial<User>): Promise<User> => {
    const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(user)
    });
    
    const data = await response.json();
    if (!response.ok) {
        throw new Error(data.error || "Registration failed");
    }
    
    localStorage.setItem('token', data.token);
    return data.user;
};

export const loginUser = async (email: string, password?: string): Promise<User> => {
    const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
    });
    
    const data = await response.json();
    if (!response.ok) {
        throw new Error(data.error || "Login failed");
    }
    
    localStorage.setItem('token', data.token);
    return data.user;
};

export const logoutUser = () => {
    localStorage.removeItem('token');
};

export const getCurrentUser = async (): Promise<User | null> => {
    const token = localStorage.getItem('token');
    if (!token) return null;
    
    try {
        const response = await fetch('/api/auth/me', {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        if (!response.ok) return null;
        return await response.json();
    } catch {
        return null;
    }
};

export const syncUserProgress = async (user: User) => {
    const token = localStorage.getItem('token');
    if (!token) return;
    
    await fetch('/api/user/progress', {
        method: 'POST',
        headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ progress: user.progress, points: user.points })
    });
};

export const getUserFolders = async () => {
    const token = localStorage.getItem('token');
    const localFolders = localStorage.getItem('edu_offline_folders');
    
    if (!token) {
        return localFolders ? JSON.parse(localFolders) : [];
    }
    
    try {
        const response = await fetch('/api/user/notebook', {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        if (!response.ok) {
            return localFolders ? JSON.parse(localFolders) : [];
        }
        const data = await response.json();
        localStorage.setItem('edu_offline_folders', JSON.stringify(data));
        return data;
    } catch {
        return localFolders ? JSON.parse(localFolders) : [];
    }
};

export const saveUserFolders = async (folders: any) => {
    localStorage.setItem('edu_offline_folders', JSON.stringify(folders));
    
    const token = localStorage.getItem('token');
    if (!token) return;
    
    try {
        await fetch('/api/user/notebook', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ folders })
        });
    } catch (e) {
        console.warn("Offline: Folders saved locally.");
    }
};
