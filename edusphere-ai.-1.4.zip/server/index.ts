import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";
import path from 'path';
import { fileURLToPath } from 'url';
import { WebSocketServer, WebSocket } from 'ws';
import http from 'http';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const app = express();
const PORT = 3000; // MUST be 3000
const JWT_SECRET = process.env.JWT_SECRET || 'edusphere_v14_secure_key_2025';

// --- IN-MEMORY STORAGE (Replaces MongoDB) ---
const db = {
  users: [] as any[],
  chats: [] as any[],
  notebooks: [] as any[],
  content: [] as any[]
};

// Middleware to check DB connection (Now always passes)
const checkDbConnection = (req: any, res: any, next: any) => {
  next();
};

// Helper functions for in-memory DB
const Content = {
  find: async (query: any) => {
    return db.content.filter(c => {
      for (let key in query) {
        if (c[key] !== query[key]) return false;
      }
      return true;
    });
  },
  save: async (data: any) => {
    db.content.push(data);
    return data;
  },
  delete: async (id: string) => {
    const index = db.content.findIndex(c => c.id === id);
    if (index !== -1) {
      db.content.splice(index, 1);
      return true;
    }
    return false;
  }
};

const User = {
  findOne: async (query: any) => {
    return db.users.find(u => {
      for (let key in query) {
        if (u[key] !== query[key]) return false;
      }
      return true;
    });
  },
  find: async (query: any) => db.users,
  findOneAndUpdate: async (query: any, update: any, options: any = {}) => {
    let userIndex = db.users.findIndex(u => {
      for (let key in query) {
        if (u[key] !== query[key]) return false;
      }
      return true;
    });

    if (userIndex === -1) {
      if (options.upsert) {
        const newUser = { ...query, ...update };
        db.users.push(newUser);
        return newUser;
      }
      return null;
    }

    // Handle Mongoose-style $push if needed
    if (update.$push) {
      for (let key in update.$push) {
        db.users[userIndex][key] = db.users[userIndex][key] || [];
        db.users[userIndex][key].push(update.$push[key]);
      }
    } else {
      db.users[userIndex] = { ...db.users[userIndex], ...update };
    }
    
    return db.users[userIndex];
  },
  save: async (userData: any) => {
    const index = db.users.findIndex(u => u.email === userData.email);
    if (index !== -1) {
      db.users[index] = userData;
    } else {
      db.users.push(userData);
    }
    return userData;
  }
};

const Chat = {
  findOne: async (query: any) => {
    return db.chats.find(c => c.userId === query.userId && c.subject === query.subject);
  },
  findOneAndUpdate: async (query: any, update: any, options: any = {}) => {
    let chatIndex = db.chats.findIndex(c => c.userId === query.userId && c.subject === query.subject);
    if (chatIndex === -1) {
      if (options.upsert) {
        const newChat = { ...query, messages: [] };
        if (update.$push) {
          newChat.messages.push(update.$push.messages);
        }
        db.chats.push(newChat);
        return newChat;
      }
      return null;
    }
    if (update.$push) {
      db.chats[chatIndex].messages.push(update.$push.messages);
    }
    return db.chats[chatIndex];
  }
};

const Notebook = {
  findOne: async (query: any) => {
    return db.notebooks.find(n => n.userId === query.userId);
  },
  findOneAndUpdate: async (query: any, update: any, options: any = {}) => {
    let index = db.notebooks.findIndex(n => n.userId === query.userId);
    if (index === -1) {
      if (options.upsert) {
        const newNb = { ...query, ...update };
        db.notebooks.push(newNb);
        return newNb;
      }
      return null;
    }
    db.notebooks[index] = { ...db.notebooks[index], ...update };
    return db.notebooks[index];
  }
};

// Initialize Gemini AI on backend using the environment secret and fallback keys
const API_KEYS = [
  process.env.API_KEY,
  'AIzaSyC5Wk6ab9GYrMEscxazQj4DLRNse9vg7AY'
].filter(Boolean) as string[];

let currentKeyIndex = 0;

const generateContentWithFallback = async (model: string, contents: any, config: any) => {
  let attempts = 0;
  while (attempts < API_KEYS.length) {
    try {
      const ai = new GoogleGenAI({ apiKey: API_KEYS[currentKeyIndex] });
      const response = await ai.models.generateContent({ model, contents, config });
      return response;
    } catch (error: any) {
      const isQuotaError = error.status === 429 || 
                           error.message?.toLowerCase().includes('quota') || 
                           error.message?.toLowerCase().includes('rate limit') ||
                           error.message?.toLowerCase().includes('429');
      
      if (isQuotaError) {
        console.warn(`⚠️ API Key at index ${currentKeyIndex} exhausted/rate-limited. Switching to next key...`);
        currentKeyIndex = (currentKeyIndex + 1) % API_KEYS.length;
        attempts++;
      } else {
        throw error;
      }
    }
  }
  throw new Error("All API keys exhausted or rate-limited.");
};

app.use(cors());
app.use(express.json({ limit: '10mb' }));

// --- Authentication Middleware ---
const authenticateToken = (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return res.sendStatus(401);

  jwt.verify(token, JWT_SECRET, (err: any, user: any) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
};

// --- GOOGLE OAUTH ROUTES ---
const getRedirectUri = (req: any) => {
  let baseUrl = process.env.APP_URL;
  if (!baseUrl) {
    const protocol = req.get('x-forwarded-proto') || req.protocol;
    baseUrl = `${protocol}://${req.get('host')}`;
  }
  baseUrl = baseUrl.replace(/\/$/, '');
  return `${baseUrl}/auth/google/callback`;
};

app.get('/api/auth/google/url', checkDbConnection, (req, res) => {
  const redirectUri = getRedirectUri(req);
  const params = new URLSearchParams({
    client_id: process.env.GOOGLE_CLIENT_ID || '',
    redirect_uri: redirectUri,
    response_type: 'code',
    scope: 'https://www.googleapis.com/auth/userinfo.profile https://www.googleapis.com/auth/userinfo.email',
    access_type: 'offline',
    prompt: 'consent',
  });
  
  const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;
  res.json({ url: authUrl });
});

app.get('/auth/google/callback', checkDbConnection, async (req, res) => {
  const { code } = req.query;
  if (!code) return res.status(400).send('No code provided');

  try {
    const redirectUri = getRedirectUri(req);
    const tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code: code as string,
        client_id: process.env.GOOGLE_CLIENT_ID || '',
        client_secret: process.env.GOOGLE_CLIENT_SECRET || '',
        redirect_uri: redirectUri,
        grant_type: 'authorization_code',
      }),
    });

    const tokens = await tokenResponse.json();
    if (tokens.error) throw new Error(tokens.error_description || tokens.error);

    const userResponse = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
      headers: { Authorization: `Bearer ${tokens.access_token}` },
    });
    const googleUser = await userResponse.json();
    
    let user = await User.findOne({ email: googleUser.email });
    
    if (!user) {
      user = {
        id: Date.now().toString(),
        name: googleUser.name,
        email: googleUser.email,
        picture: googleUser.picture,
        educationLevel: 'General Learner',
        points: 0, streak: 1,
        progress: { masteredTopics: [], totalStudyMinutes: 0, subjectStrengths: {}, recentActivity: [] }
      };
      await User.save(user);
    }

    const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET);
    
    res.send(`
      <script>
        if (window.opener) {
          window.opener.postMessage({ type: 'GOOGLE_AUTH_SUCCESS', user: ${JSON.stringify(user)}, token: '${token}' }, '*');
          window.close();
        } else {
          window.location.href = '/dashboard';
        }
      </script>
      <p>Authentication successful. You can close this window.</p>
    `);
  } catch (error: any) {
    console.error('Google Auth Error:', error);
    res.status(400).send(`Authentication failed: ${error.message}`);
  }
});

// --- AUTHENTICATION ROUTES ---
app.post('/api/auth/register', checkDbConnection, async (req, res) => {
  const { name, email, password, educationLevel } = req.body;
  const existing = await User.findOne({ email });
  if (existing) return res.status(400).json({ error: "Email already registered" });
  
  const newUser = {
    id: Date.now().toString(),
    name, email, password, educationLevel,
    progress: { masteredTopics: [], totalStudyMinutes: 0, subjectStrengths: {}, recentActivity: [] }
  };
  await User.save(newUser);
  const token = jwt.sign({ id: newUser.id, email: newUser.email }, JWT_SECRET);
  res.json({ user: newUser, token });
});

app.post('/api/auth/login', checkDbConnection, async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email, password });
  if (!user) return res.status(401).json({ error: "Invalid email or password" });
  
  const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET);
  res.json({ user, token });
});

app.get('/api/auth/me', authenticateToken, checkDbConnection, async (req: any, res) => {
  const user = await User.findOne({ id: req.user.id });
  if (!user) return res.sendStatus(404);
  res.json(user);
});

// --- ADMIN MIDDLEWARE ---
const checkAdmin = (req: any, res: any, next: any) => {
  if (req.user.email !== 'sppandey5@gmail.com') {
    return res.status(403).json({ error: "Access denied. Admin only." });
  }
  next();
};

// --- ADMIN ROUTES ---
app.get('/api/admin/users', authenticateToken, checkAdmin, checkDbConnection, async (req, res) => {
  const users = await User.find({});
  res.json(users);
});

app.post('/api/admin/content', authenticateToken, checkAdmin, checkDbConnection, async (req, res) => {
  const { type, data } = req.body;
  if (!type || !data) return res.status(400).json({ error: "Missing type or data" });
  
  const newItem = {
    id: Date.now().toString(),
    type,
    ...data,
    createdAt: new Date().toISOString()
  };
  
  await Content.save(newItem);
  res.json(newItem);
});

app.delete('/api/admin/content/:id', authenticateToken, checkAdmin, checkDbConnection, async (req, res) => {
  const success = await Content.delete(req.params.id);
  if (success) res.json({ success: true });
  else res.status(404).json({ error: "Content not found" });
});

// --- PUBLIC CONTENT ROUTES ---
app.get('/api/content/:type', checkDbConnection, async (req, res) => {
  const content = await Content.find({ type: req.params.type });
  res.json(content);
});

// --- AI PROXY ROUTES ---
app.post('/api/ai/generate', authenticateToken, async (req, res) => {
  try {
    const { prompt, config, model = 'gemini-3-flash-preview' } = req.body;
    const response = await generateContentWithFallback(model, prompt, config);
    res.json({ text: response.text, candidates: response.candidates });
  } catch (error: any) {
    console.error("Gemini Proxy Error:", error);
    res.status(400).json({ error: error.message });
  }
});

// --- PERSISTENCE ROUTES ---
app.get('/api/user/notebook', authenticateToken, checkDbConnection, async (req: any, res) => {
  const notebook = await Notebook.findOne({ userId: req.user.id });
  res.json(notebook?.folders || []);
});

app.post('/api/user/notebook', authenticateToken, checkDbConnection, async (req: any, res) => {
  await Notebook.findOneAndUpdate(
    { userId: req.user.id },
    { folders: req.body.folders },
    { upsert: true }
  );
  res.json({ success: true });
});

app.get('/api/chat/:subject', authenticateToken, checkDbConnection, async (req: any, res) => {
  const chat = await Chat.findOne({ userId: req.user.id, subject: req.params.subject });
  res.json(chat?.messages || []);
});

app.post('/api/chat/:subject', authenticateToken, checkDbConnection, async (req: any, res) => {
  await Chat.findOneAndUpdate(
    { userId: req.user.id, subject: req.params.subject },
    { $push: { messages: req.body.message } },
    { upsert: true }
  );
  res.json({ success: true });
});

app.post('/api/user/progress', authenticateToken, checkDbConnection, async (req: any, res) => {
  const user = await User.findOneAndUpdate(
    { id: req.user.id },
    { progress: req.body.progress, points: req.body.points },
    { new: true }
  );
  if (!user) return res.sendStatus(404);
  res.json(user);
});

const startServer = async () => {
  const server = http.createServer(app);
  
  // --- WebSocket Server ---
  const wss = new WebSocketServer({ server });
  const rooms = new Map<string, Set<WebSocket>>();

  wss.on('connection', (ws, req) => {
    let currentRoom: string | null = null;
    let userId: string | null = null;

    ws.on('message', (data) => {
      try {
        const message = JSON.parse(data.toString());
        
        if (message.type === 'join') {
          currentRoom = message.room;
          userId = message.userId;
          if (!rooms.has(currentRoom!)) {
            rooms.set(currentRoom!, new Set());
          }
          rooms.get(currentRoom!)!.add(ws);
          
          // Broadcast join
          const joinMsg = JSON.stringify({ type: 'user_joined', userId, timestamp: Date.now() });
          rooms.get(currentRoom!)!.forEach(client => {
            if (client !== ws && client.readyState === WebSocket.OPEN) {
              client.send(joinMsg);
            }
          });
        }
        
        if (message.type === 'chat' || message.type === 'draw') {
          if (currentRoom && rooms.has(currentRoom)) {
            rooms.get(currentRoom)!.forEach(client => {
              if (client !== ws && client.readyState === WebSocket.OPEN) {
                client.send(JSON.stringify(message));
              }
            });
          }
        }
      } catch (e) {
        console.error("WS Message Error:", e);
      }
    });

    ws.on('close', () => {
      if (currentRoom && rooms.has(currentRoom)) {
        rooms.get(currentRoom)!.delete(ws);
        if (rooms.get(currentRoom)!.size === 0) {
          rooms.delete(currentRoom);
        } else {
          const leaveMsg = JSON.stringify({ type: 'user_left', userId, timestamp: Date.now() });
          rooms.get(currentRoom)!.forEach(client => {
            if (client.readyState === WebSocket.OPEN) {
              client.send(leaveMsg);
            }
          });
        }
      }
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, '../dist')));
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`EduSphere Secure Backend running on port ${PORT}`);
  });
};

startServer();
