import React, { useEffect, useState } from 'react';
import { User } from '../types';
import { 
  Users, Newspaper, Lightbulb, BookOpen, Brain, Plus, Trash2, 
  Save, X, CheckCircle, AlertCircle, Loader2 
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

type Tab = 'users' | 'news' | 'facts' | 'deep-dive' | 'quiz';

export const AdminDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>('users');
  const [users, setUsers] = useState<User[]>([]);
  const [content, setContent] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);

  // Form States
  const [newItem, setNewItem] = useState<any>({});

  useEffect(() => {
    fetchData();
  }, [activeTab]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const headers = { 'Authorization': `Bearer ${token}` };

      if (activeTab === 'users') {
        const res = await fetch('/api/admin/users', { headers });
        if (res.ok) setUsers(await res.json());
      } else {
        const res = await fetch(`/api/content/${activeTab}`, { headers });
        if (res.ok) setContent(await res.json());
      }
    } catch (error) {
      console.error('Fetch error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure?')) return;
    try {
      const token = localStorage.getItem('token');
      await fetch(`/api/admin/content/${id}`, {
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      fetchData();
    } catch (error) {
      console.error('Delete error:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const token = localStorage.getItem('token');
      const res = await fetch('/api/admin/content', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          type: activeTab,
          data: newItem
        })
      });
      
      if (res.ok) {
        setShowAddModal(false);
        setNewItem({});
        fetchData();
      }
    } catch (error) {
      console.error('Submit error:', error);
    } finally {
      setSubmitting(false);
    }
  };

  const renderContentList = () => {
    if (loading) return <div className="p-8 text-center"><Loader2 className="animate-spin mx-auto" /></div>;

    if (activeTab === 'users') {
      return (
        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
          <table className="w-full text-left">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="p-4 text-xs font-bold text-slate-500 uppercase">User</th>
                <th className="p-4 text-xs font-bold text-slate-500 uppercase">Email</th>
                <th className="p-4 text-xs font-bold text-slate-500 uppercase">Level</th>
                <th className="p-4 text-xs font-bold text-slate-500 uppercase">XP</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {users.map(user => (
                <tr key={user.id} className="hover:bg-slate-50">
                  <td className="p-4 font-medium">{user.name}</td>
                  <td className="p-4 text-slate-600">{user.email}</td>
                  <td className="p-4"><span className="px-2 py-1 bg-blue-50 text-blue-600 rounded-full text-xs font-bold">{user.educationLevel}</span></td>
                  <td className="p-4 font-bold text-indigo-600">{user.points}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      );
    }

    return (
      <div className="grid gap-4">
        {content.map(item => (
          <div key={item.id} className="bg-white p-4 rounded-xl border border-slate-200 flex justify-between items-start">
            <div>
              <h3 className="font-bold text-slate-900">{item.title || item.content?.substring(0, 50)}...</h3>
              <p className="text-sm text-slate-500 mt-1">{item.category} • {new Date(item.createdAt).toLocaleDateString()}</p>
            </div>
            <button onClick={() => handleDelete(item.id)} className="text-red-500 hover:bg-red-50 p-2 rounded-lg">
              <Trash2 size={18} />
            </button>
          </div>
        ))}
      </div>
    );
  };

  const renderForm = () => {
    switch (activeTab) {
      case 'news':
        return (
          <>
            <input className="w-full p-3 border rounded-xl mb-3" placeholder="Title" value={newItem.title || ''} onChange={e => setNewItem({...newItem, title: e.target.value})} required />
            <textarea className="w-full p-3 border rounded-xl mb-3" placeholder="Summary" rows={3} value={newItem.summary || ''} onChange={e => setNewItem({...newItem, summary: e.target.value})} required />
            <input className="w-full p-3 border rounded-xl mb-3" placeholder="Source Name" value={newItem.source || ''} onChange={e => setNewItem({...newItem, source: e.target.value})} required />
            <input className="w-full p-3 border rounded-xl mb-3" placeholder="URL" value={newItem.url || ''} onChange={e => setNewItem({...newItem, url: e.target.value})} />
            <select className="w-full p-3 border rounded-xl mb-3" value={newItem.category || ''} onChange={e => setNewItem({...newItem, category: e.target.value})} required>
              <option value="">Select Category</option>
              <option value="Technology">Technology</option>
              <option value="Science">Science</option>
              <option value="Education">Education</option>
              <option value="Current Affairs">Current Affairs</option>
            </select>
          </>
        );
      case 'facts':
        return (
          <>
            <textarea className="w-full p-3 border rounded-xl mb-3" placeholder="Fact Content" rows={3} value={newItem.content || ''} onChange={e => setNewItem({...newItem, content: e.target.value})} required />
            <input className="w-full p-3 border rounded-xl mb-3" placeholder="Category" value={newItem.category || ''} onChange={e => setNewItem({...newItem, category: e.target.value})} required />
            <input className="w-full p-3 border rounded-xl mb-3" placeholder="Source (Optional)" value={newItem.source || ''} onChange={e => setNewItem({...newItem, source: e.target.value})} />
          </>
        );
      case 'deep-dive':
        return (
          <>
            <input className="w-full p-3 border rounded-xl mb-3" placeholder="Title" value={newItem.title || ''} onChange={e => setNewItem({...newItem, title: e.target.value})} required />
            <textarea className="w-full p-3 border rounded-xl mb-3" placeholder="Content (Markdown supported)" rows={6} value={newItem.content || ''} onChange={e => setNewItem({...newItem, content: e.target.value})} required />
            <input className="w-full p-3 border rounded-xl mb-3" placeholder="Category" value={newItem.category || ''} onChange={e => setNewItem({...newItem, category: e.target.value})} required />
            <input className="w-full p-3 border rounded-xl mb-3" placeholder="Image URL (Optional)" value={newItem.imageUrl || ''} onChange={e => setNewItem({...newItem, imageUrl: e.target.value})} />
          </>
        );
      case 'quiz':
        return (
          <div className="space-y-3">
            <input className="w-full p-3 border rounded-xl" placeholder="Quiz Title" value={newItem.title || ''} onChange={e => setNewItem({...newItem, title: e.target.value})} required />
            <select className="w-full p-3 border rounded-xl" value={newItem.category || ''} onChange={e => setNewItem({...newItem, category: e.target.value})} required>
                <option value="">Select Subject</option>
                {['Mathematics', 'Science', 'History', 'Geography', 'English', 'Physics', 'Chemistry', 'Biology', 'Computer Science', 'General Knowledge'].map(s => (
                    <option key={s} value={s}>{s}</option>
                ))}
            </select>
            <p className="text-sm text-slate-500">Questions (JSON Format):</p>
            <textarea 
                className="w-full p-3 border rounded-xl font-mono text-xs" 
                placeholder='[{"question": "...", "options": ["A", "B", "C", "D"], "correctAnswer": 0, "rationale": "..."}]' 
                rows={10} 
                value={newItem.questionsJSON || ''} 
                onChange={e => setNewItem({...newItem, questionsJSON: e.target.value})} 
                required 
            />
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-black text-slate-900">Admin Panel</h1>
          <div className="flex gap-2">
            <span className="px-3 py-1 bg-indigo-100 text-indigo-700 rounded-full text-sm font-bold">
              Admin: sppandey5@gmail.com
            </span>
          </div>
        </div>

        <div className="grid grid-cols-12 gap-8">
          {/* Sidebar */}
          <div className="col-span-3 space-y-2">
            {[
              { id: 'users', label: 'Users', icon: Users },
              { id: 'news', label: 'News Feed', icon: Newspaper },
              { id: 'facts', label: 'Facts', icon: Lightbulb },
              { id: 'deep-dive', label: 'Deep Dive', icon: BookOpen },
              { id: 'quiz', label: 'Quiz Hub', icon: Brain },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as Tab)}
                className={`w-full flex items-center gap-3 p-4 rounded-xl font-bold transition-all ${
                  activeTab === tab.id 
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200' 
                    : 'bg-white text-slate-600 hover:bg-slate-100'
                }`}
              >
                <tab.icon size={20} />
                {tab.label}
              </button>
            ))}
          </div>

          {/* Main Content */}
          <div className="col-span-9">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-slate-800 capitalize">{activeTab.replace('-', ' ')}</h2>
              {activeTab !== 'users' && (
                <button 
                  onClick={() => setShowAddModal(true)}
                  className="flex items-center gap-2 bg-indigo-600 text-white px-4 py-2 rounded-xl font-bold hover:bg-indigo-700 transition-colors"
                >
                  <Plus size={20} />
                  Add New
                </button>
              )}
            </div>

            {renderContentList()}
          </div>
        </div>
      </div>

      {/* Add Modal */}
      <AnimatePresence>
        {showAddModal && (
          <motion.div 
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          >
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
              className="bg-white rounded-2xl w-full max-w-lg p-6 shadow-2xl"
            >
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold text-slate-900">Add {activeTab}</h3>
                <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">
                  <X size={24} />
                </button>
              </div>

              <form onSubmit={handleSubmit}>
                {renderForm()}
                
                <div className="flex justify-end gap-3 mt-6">
                  <button type="button" onClick={() => setShowAddModal(false)} className="px-4 py-2 text-slate-600 font-bold hover:bg-slate-100 rounded-xl">
                    Cancel
                  </button>
                  <button 
                    type="submit" 
                    disabled={submitting}
                    className="px-6 py-2 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 disabled:opacity-50 flex items-center gap-2"
                  >
                    {submitting ? <Loader2 className="animate-spin" size={18} /> : <Save size={18} />}
                    Save Content
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
