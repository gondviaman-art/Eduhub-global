import React, { useState, useEffect } from 'react';
import { Book, Search, Download, Trash2, Volume2 } from 'lucide-react';
import { getAI, getLangInstruction } from '../services/geminiService';
import { useAppContext } from '../App';
import { Type } from '@google/genai';

interface DictionaryEntry {
    word: string;
    definition: string;
    example: string;
    synonyms: string[];
}

export const Dictionary: React.FC = () => {
    const { language } = useAppContext();
    const [query, setQuery] = useState('');
    const [loading, setLoading] = useState(false);
    const [entry, setEntry] = useState<DictionaryEntry | null>(null);
    const [savedWords, setSavedWords] = useState<DictionaryEntry[]>([]);

    useEffect(() => {
        const saved = localStorage.getItem('edu_offline_dict');
        if (saved) {
            setSavedWords(JSON.parse(saved));
        }
    }, []);

    const saveToOffline = (newEntry: DictionaryEntry) => {
        const updated = [newEntry, ...savedWords.filter(w => w.word.toLowerCase() !== newEntry.word.toLowerCase())];
        setSavedWords(updated);
        localStorage.setItem('edu_offline_dict', JSON.stringify(updated));
    };

    const deleteWord = (word: string) => {
        const updated = savedWords.filter(w => w.word !== word);
        setSavedWords(updated);
        localStorage.setItem('edu_offline_dict', JSON.stringify(updated));
    };

    const handleSearch = async (e?: React.FormEvent, searchWord?: string) => {
        if (e) e.preventDefault();
        const wordToSearch = (searchWord || query).trim().toLowerCase();
        if (!wordToSearch) return;

        // Check offline cache first
        const offlineMatch = savedWords.find(w => w.word.toLowerCase() === wordToSearch);
        if (offlineMatch) {
            setEntry(offlineMatch);
            setQuery(wordToSearch);
            return;
        }

        setLoading(true);
        try {
            const ai = getAI();
            const response = await ai.models.generateContent({
                model: 'gemini-3-flash-preview',
                contents: `Define the word "${wordToSearch}" comprehensively. ${getLangInstruction(language)}`,
                config: {
                    responseMimeType: "application/json",
                    responseSchema: {
                        type: Type.OBJECT,
                        properties: {
                            word: { type: Type.STRING },
                            definition: { type: Type.STRING },
                            example: { type: Type.STRING },
                            synonyms: { type: Type.ARRAY, items: { type: Type.STRING } }
                        },
                        required: ["word", "definition", "example", "synonyms"]
                    }
                }
            });

            const text = response.text || "{}";
            const cleaned = text.replace(/```json/g, '').replace(/```/g, '').trim();
            const data = JSON.parse(cleaned) as DictionaryEntry;
            
            if (data && data.word) {
                setEntry(data);
                saveToOffline(data);
            } else {
                alert("Word not found.");
            }
        } catch (error) {
            console.error(error);
            alert("Error fetching definition. You might be offline.");
        } finally {
            setLoading(false);
        }
    };

    const speak = (text: string) => {
        const utterance = new SpeechSynthesisUtterance(text);
        window.speechSynthesis.speak(utterance);
    };

    return (
        <div className="max-w-4xl mx-auto space-y-8 pb-20 animate-in fade-in duration-500">
            <div className="bg-white p-8 rounded-[2rem] shadow-sm border border-slate-100">
                <div className="flex items-center gap-4 mb-6">
                    <div className="w-12 h-12 rounded-2xl bg-indigo-50 flex items-center justify-center text-indigo-600">
                        <Book size={24} />
                    </div>
                    <div>
                        <h1 className="text-2xl font-bold text-slate-900">Offline Dictionary</h1>
                        <p className="text-slate-500">Search words and access them anytime, even without internet.</p>
                    </div>
                </div>

                <form onSubmit={handleSearch} className="flex gap-4 flex-col md:flex-row">
                    <div className="relative flex-1">
                        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
                        <input
                            type="text"
                            value={query}
                            onChange={(e) => setQuery(e.target.value)}
                            placeholder="Search any word..."
                            className="w-full bg-slate-50 border-none rounded-2xl pl-12 pr-6 py-4 text-slate-700 focus:ring-2 focus:ring-indigo-500 outline-none font-medium"
                        />
                    </div>
                    <button
                        type="submit"
                        disabled={loading || !query.trim()}
                        className="bg-indigo-600 text-white px-8 py-4 rounded-2xl font-medium hover:bg-indigo-700 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                        {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Search size={20} />}
                        Search
                    </button>
                </form>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {/* Result Area */}
                <div className="md:col-span-2 space-y-6">
                    {entry ? (
                        <div className="bg-white p-8 rounded-[2rem] shadow-sm border border-slate-100 animate-in slide-in-from-bottom-4">
                            <div className="flex justify-between items-start mb-6">
                                <div>
                                    <h2 className="text-4xl font-black text-slate-900 capitalize mb-2">{entry.word}</h2>
                                    <button onClick={() => speak(entry.word)} className="text-indigo-600 flex items-center gap-2 text-sm font-bold hover:text-indigo-700 bg-indigo-50 px-3 py-1.5 rounded-lg">
                                        <Volume2 size={16} /> Pronounce
                                    </button>
                                </div>
                                <div className="bg-emerald-50 text-emerald-600 px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                                    <Download size={12} /> Saved Offline
                                </div>
                            </div>
                            
                            <div className="space-y-6">
                                <div>
                                    <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-2">Definition</h3>
                                    <p className="text-lg text-slate-700 leading-relaxed font-medium">{entry.definition}</p>
                                </div>
                                
                                <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100">
                                    <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-2">Example</h3>
                                    <p className="text-slate-600 italic">"{entry.example}"</p>
                                </div>

                                <div>
                                    <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-3">Synonyms</h3>
                                    <div className="flex flex-wrap gap-2">
                                        {entry.synonyms.map((syn, i) => (
                                            <button 
                                                key={i} 
                                                onClick={() => handleSearch(undefined, syn)}
                                                className="px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm font-medium text-slate-600 hover:border-indigo-500 hover:text-indigo-600 transition-colors"
                                            >
                                                {syn}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        </div>
                    ) : (
                        <div className="bg-slate-50/50 border-2 border-dashed border-slate-200 rounded-[2rem] h-64 flex flex-col items-center justify-center text-slate-400">
                            <Book size={48} className="mb-4 opacity-20" />
                            <p className="font-medium">Search for a word to see its definition.</p>
                        </div>
                    )}
                </div>

                {/* Offline Saved Words List */}
                <div className="bg-white rounded-[2rem] shadow-sm border border-slate-100 overflow-hidden flex flex-col h-[600px]">
                    <div className="p-6 border-b border-slate-100 bg-slate-50/50">
                        <h3 className="font-black text-slate-900 flex items-center gap-2">
                            <Download className="w-5 h-5 text-indigo-600" />
                            Saved Offline ({savedWords.length})
                        </h3>
                    </div>
                    <div className="flex-1 overflow-y-auto p-4 space-y-2 custom-scrollbar">
                        {savedWords.length === 0 ? (
                            <p className="text-center text-slate-400 text-sm mt-10">No words saved yet.</p>
                        ) : (
                            savedWords.map((w, i) => (
                                <div key={i} className="flex items-center justify-between p-4 rounded-xl hover:bg-slate-50 group border border-transparent hover:border-slate-100 transition-colors">
                                    <button 
                                        onClick={() => { setEntry(w); setQuery(w.word); }}
                                        className="flex-1 text-left font-bold text-slate-700 group-hover:text-indigo-600 capitalize truncate"
                                    >
                                        {w.word}
                                    </button>
                                    <button 
                                        onClick={() => deleteWord(w.word)}
                                        className="text-slate-300 hover:text-rose-500 p-2 rounded-lg hover:bg-rose-50 opacity-0 group-hover:opacity-100 transition-all"
                                    >
                                        <Trash2 size={16} />
                                    </button>
                                </div>
                            ))
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};
