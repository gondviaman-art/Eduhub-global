
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Stage, Layer, Line } from 'react-konva';
import { useAppContext } from '../App';
import { Users, MessageSquare, Pencil, Eraser, Trash2, Send, LogOut, Share2, Download } from 'lucide-react';

interface ChatMessage {
    userId: string;
    userName: string;
    text: string;
    timestamp: number;
}

interface DrawingLine {
    tool: string;
    points: number[];
    color: string;
}

export const StudyGroup: React.FC = () => {
    const { user } = useAppContext();
    const [room, setRoom] = useState('');
    const [joined, setJoined] = useState(false);
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [inputText, setInputText] = useState('');
    const [lines, setLines] = useState<DrawingLine[]>([]);
    const [tool, setTool] = useState('pen');
    const [color, setColor] = useState('#4f46e5');
    const [participants, setParticipants] = useState<string[]>([]);
    
    const socketRef = useRef<WebSocket | null>(null);
    const isDrawing = useRef(false);
    const stageRef = useRef<any>(null);

    useEffect(() => {
        if (joined && user) {
            const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
            const socket = new WebSocket(`${protocol}//${window.location.host}`);
            socketRef.current = socket;

            socket.onopen = () => {
                socket.send(JSON.stringify({ type: 'join', room, userId: user.id }));
            };

            socket.onmessage = (event) => {
                const data = JSON.parse(event.data);
                if (data.type === 'chat') {
                    setMessages(prev => [...prev, data.message]);
                } else if (data.type === 'draw') {
                    setLines(prev => [...prev, data.line]);
                } else if (data.type === 'user_joined') {
                    setParticipants(prev => [...new Set([...prev, data.userId])]);
                } else if (data.type === 'user_left') {
                    setParticipants(prev => prev.filter(id => id !== data.userId));
                }
            };

            return () => {
                socket.close();
            };
        }
    }, [joined, room, user]);

    const handleSend = (e: React.FormEvent) => {
        e.preventDefault();
        if (!inputText.trim() || !socketRef.current || !user) return;

        const msg: ChatMessage = {
            userId: user.id,
            userName: user.name,
            text: inputText,
            timestamp: Date.now()
        };

        socketRef.current.send(JSON.stringify({ type: 'chat', message: msg }));
        setMessages(prev => [...prev, msg]);
        setInputText('');
    };

    const handleMouseDown = (e: any) => {
        isDrawing.current = true;
        const pos = e.target.getStage().getPointerPosition();
        setLines([...lines, { tool, points: [pos.x, pos.y], color: tool === 'eraser' ? '#ffffff' : color }]);
    };

    const handleMouseMove = (e: any) => {
        if (!isDrawing.current) return;
        const stage = e.target.getStage();
        const point = stage.getPointerPosition();
        let lastLine = lines[lines.length - 1];
        lastLine.points = lastLine.points.concat([point.x, point.y]);
        lines.splice(lines.length - 1, 1, lastLine);
        setLines(lines.concat());
    };

    const handleMouseUp = () => {
        isDrawing.current = false;
        if (socketRef.current) {
            socketRef.current.send(JSON.stringify({ type: 'draw', line: lines[lines.length - 1] }));
        }
    };

    const downloadWhiteboard = () => {
        if (!stageRef.current) return;
        const uri = stageRef.current.toDataURL();
        const link = document.createElement('a');
        link.download = `EduSphere-Whiteboard-${room}.png`;
        link.href = uri;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    if (!joined) {
        return (
            <div className="h-[80vh] flex items-center justify-center p-4">
                <div className="bg-white p-8 sm:p-12 rounded-[3rem] shadow-2xl border border-slate-100 max-w-md w-full text-center">
                    <div className="w-20 h-20 bg-indigo-100 rounded-3xl flex items-center justify-center mx-auto mb-8 text-indigo-600">
                        <Users className="w-10 h-10" />
                    </div>
                    <h2 className="text-3xl font-black text-slate-900 mb-4 tracking-tighter">Join a Study Group</h2>
                    <p className="text-slate-500 mb-8 font-medium">Collaborate with peers in real-time on a shared whiteboard and chat.</p>
                    
                    <div className="space-y-4">
                        <input 
                            type="text" 
                            placeholder="Enter Room Name (e.g. Physics-101)" 
                            value={room}
                            onChange={(e) => setRoom(e.target.value)}
                            className="w-full p-4 rounded-2xl border border-slate-200 focus:ring-2 focus:ring-indigo-500 outline-none font-bold"
                        />
                        <button 
                            onClick={() => room && setJoined(true)}
                            className="w-full bg-slate-900 text-white py-4 rounded-2xl font-black shadow-xl hover:bg-indigo-600 transition-all active:scale-95"
                        >
                            Join Room
                        </button>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="h-[calc(100vh-120px)] flex flex-col gap-6 animate-in fade-in duration-500">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-6 rounded-[2rem] shadow-sm border border-slate-100">
                <div className="flex items-center gap-4">
                    <div className="bg-indigo-600 p-3 rounded-2xl text-white shadow-lg shadow-indigo-200">
                        <Users className="w-6 h-6" />
                    </div>
                    <div>
                        <h2 className="text-2xl font-black text-slate-900 tracking-tight">Room: {room}</h2>
                        <p className="text-slate-400 text-xs font-bold uppercase tracking-widest flex items-center gap-2">
                            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" /> {participants.length + 1} Active Now
                        </p>
                    </div>
                </div>
                <div className="flex gap-3 w-full sm:w-auto">
                    <button onClick={() => {
                        const url = window.location.href;
                        navigator.clipboard.writeText(url);
                        alert("Room link copied!");
                    }} className="flex-1 sm:flex-none bg-slate-50 text-slate-600 px-6 py-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-slate-100 transition-all">
                        <Share2 className="w-4 h-4" /> Share
                    </button>
                    <button onClick={() => setJoined(false)} className="flex-1 sm:flex-none bg-rose-50 text-rose-600 px-6 py-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-rose-100 transition-all">
                        <LogOut className="w-4 h-4" /> Leave
                    </button>
                </div>
            </div>

            <div className="flex-1 flex flex-col lg:flex-row gap-6 min-h-0">
                {/* Whiteboard */}
                <div className="flex-1 bg-white rounded-[2.5rem] shadow-sm border border-slate-100 flex flex-col overflow-hidden relative">
                    <div className="absolute top-6 left-6 z-10 flex gap-2 bg-white/80 backdrop-blur-md p-2 rounded-2xl shadow-lg border border-slate-100">
                        <button onClick={() => setTool('pen')} className={`p-3 rounded-xl transition-all ${tool === 'pen' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:bg-slate-100'}`}>
                            <Pencil className="w-5 h-5" />
                        </button>
                        <button onClick={() => setTool('eraser')} className={`p-3 rounded-xl transition-all ${tool === 'eraser' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:bg-slate-100'}`}>
                            <Eraser className="w-5 h-5" />
                        </button>
                        <div className="w-px bg-slate-100 mx-1" />
                        <button onClick={() => setLines([])} className="p-3 rounded-xl text-rose-500 hover:bg-rose-50 transition-all">
                            <Trash2 className="w-5 h-5" />
                        </button>
                        <div className="w-px bg-slate-100 mx-1" />
                        <button onClick={downloadWhiteboard} className="p-3 rounded-xl text-emerald-600 hover:bg-emerald-50 transition-all" title="Download Whiteboard">
                            <Download className="w-5 h-5" />
                        </button>
                    </div>

                    <div className="absolute top-6 right-6 z-10 flex gap-2 bg-white/80 backdrop-blur-md p-2 rounded-2xl shadow-lg border border-slate-100">
                        {['#4f46e5', '#ef4444', '#10b981', '#f59e0b', '#000000'].map(c => (
                            <button 
                                key={c} 
                                onClick={() => setColor(c)}
                                className={`w-8 h-8 rounded-lg transition-all ${color === c ? 'ring-2 ring-offset-2 ring-indigo-500 scale-110' : 'hover:scale-110'}`}
                                style={{ backgroundColor: c }}
                            />
                        ))}
                    </div>

                    <div className="flex-1 bg-slate-50 cursor-crosshair">
                        <Stage 
                            ref={stageRef}
                            width={window.innerWidth > 1024 ? window.innerWidth - 600 : window.innerWidth - 40} 
                            height={600}
                            onMouseDown={handleMouseDown}
                            onMouseMove={handleMouseMove}
                            onMouseUp={handleMouseUp}
                        >
                            <Layer>
                                {lines.map((line, i) => (
                                    <Line
                                        key={i}
                                        points={line.points}
                                        stroke={line.color}
                                        strokeWidth={line.tool === 'eraser' ? 30 : 5}
                                        tension={0.5}
                                        lineCap="round"
                                        lineJoin="round"
                                        globalCompositeOperation={
                                            line.tool === 'eraser' ? 'destination-out' : 'source-over'
                                        }
                                    />
                                ))}
                            </Layer>
                        </Stage>
                    </div>
                </div>

                {/* Chat */}
                <div className="w-full lg:w-96 bg-white rounded-[2.5rem] shadow-sm border border-slate-100 flex flex-col overflow-hidden">
                    <div className="p-6 border-b border-slate-100 flex items-center gap-3">
                        <MessageSquare className="w-5 h-5 text-indigo-600" />
                        <h3 className="font-black text-slate-900 tracking-tight">Group Chat</h3>
                    </div>
                    
                    <div className="flex-1 overflow-y-auto p-6 space-y-4 no-scrollbar">
                        {messages.map((msg, i) => (
                            <div key={i} className={`flex flex-col ${msg.userId === user?.id ? 'items-end' : 'items-start'}`}>
                                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1 ml-1">{msg.userName}</span>
                                <div className={`px-4 py-2 rounded-2xl max-w-[90%] text-sm font-medium ${msg.userId === user?.id ? 'bg-indigo-600 text-white rounded-tr-none' : 'bg-slate-100 text-slate-700 rounded-tl-none'}`}>
                                    {msg.text}
                                </div>
                            </div>
                        ))}
                    </div>

                    <form onSubmit={handleSend} className="p-6 border-t border-slate-100 flex gap-2">
                        <input 
                            type="text" 
                            placeholder="Type a message..." 
                            value={inputText}
                            onChange={(e) => setInputText(e.target.value)}
                            className="flex-1 bg-slate-50 px-4 py-3 rounded-xl border-none focus:ring-2 focus:ring-indigo-500 outline-none text-sm font-medium"
                        />
                        <button type="submit" className="bg-indigo-600 text-white p-3 rounded-xl shadow-lg hover:bg-indigo-700 transition-all active:scale-95">
                            <Send className="w-5 h-5" />
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
};
