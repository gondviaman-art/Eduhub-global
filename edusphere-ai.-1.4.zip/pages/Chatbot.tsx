
import React, { useState, useRef, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { ChatMessage } from '../types';
import { Send, Bot, Trash2, Loader2, Sparkles, MessageSquare, Mic, Video, Info, Copy, Share2, X, Image as ImageIcon, Search, MapPin, Volume2, FileUp, Paperclip, BookOpen, FileText, Library, Code, Globe, Headphones, ChevronDown, ExternalLink, Key, Calendar } from 'lucide-react';
import { streamGeminiResponse, getLangInstruction, generateVideo, generateImage, performGlobalSearch, searchPlaces, generateSpeech, summarizeTopic, GeminiModel } from '../services/geminiService';
import { useAppContext } from '../App';

import { StudyBuddy } from './StudyBuddy';
import { LiveTutor } from './LiveTutor';
import { DocuMind } from './DocuMind';
import { NotebookLM } from './NotebookLM';
import { CodeLab } from './CodeLab';
import { LinguaSphere } from './LinguaSphere';
import { AudioStudio } from './AudioStudio';

import Markdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { atomDark } from 'react-syntax-highlighter/dist/esm/styles/prism';

/**
 * Enhanced Markdown component with syntax highlighting
 */
const RichText: React.FC<{ text: string; isUser: boolean }> = ({ text, isUser }) => {
    return (
        <div className={`markdown-body prose prose-sm md:prose-lg max-w-none ${isUser ? 'text-white prose-invert' : 'text-slate-700 prose-slate'}`}>
            <Markdown 
                remarkPlugins={[remarkGfm]}
                components={{
                    code({ node, inline, className, children, ...props }: any) {
                        const match = /language-(\w+)/.exec(className || '');
                        return !inline && match ? (
                            <SyntaxHighlighter
                                style={atomDark}
                                language={match[1]}
                                PreTag="div"
                                className="rounded-xl my-4"
                                {...props}
                            >
                                {String(children).replace(/\n$/, '')}
                            </SyntaxHighlighter>
                        ) : (
                            <code className={`${className} bg-slate-100 px-1.5 py-0.5 rounded text-indigo-600 font-bold`} {...props}>
                                {children}
                            </code>
                        );
                    }
                }}
            >
                {text}
            </Markdown>
        </div>
    );
};

export const Chatbot: React.FC = () => {
  const { t, language } = useAppContext();
  const location = useLocation();
  const navigate = useNavigate();
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    const saved = localStorage.getItem('edusphere_chat_history');
    return saved ? JSON.parse(saved) : [];
  });
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isGeneratingVideo, setIsGeneratingVideo] = useState(false);
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [videoPrompt, setVideoPrompt] = useState('');
  const [imagePrompt, setImagePrompt] = useState('');
  const [showVideoModal, setShowVideoModal] = useState(false);
  const [showImageModal, setShowImageModal] = useState(false);
  const [searchMode, setSearchMode] = useState(false);
  const [mapsMode, setMapsMode] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [fileBase64, setFileBase64] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState(() => {
    const state = location.state as { tab?: string };
    return state?.tab || 'chat';
  });
  const [selectedModel, setSelectedModel] = useState<GeminiModel>('gemini-3-flash-preview');
  const [showModelSelector, setShowModelSelector] = useState(false);
  const [hasApiKey, setHasApiKey] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const checkKey = async () => {
        if (window.aistudio) {
            const hasKey = await window.aistudio.hasSelectedApiKey();
            setHasApiKey(hasKey);
        }
    };
    checkKey();
  }, []);

  useEffect(() => {
    if (location.state && (location.state as any).tab) {
        setActiveTab((location.state as any).tab);
    }
  }, [location.state]);

  const tabs = [
    { id: 'chat', label: 'Doubt Solver', icon: <Bot className="w-4 h-4 sm:w-5 sm:h-5" /> },
    { id: 'study-buddy', label: 'Study Buddy', icon: <BookOpen className="w-4 h-4 sm:w-5 sm:h-5" /> },
    { id: 'live-tutor', label: 'Live Tutor', icon: <Mic className="w-4 h-4 sm:w-5 sm:h-5" /> },
    { id: 'documind', label: 'DocuMind', icon: <FileText className="w-4 h-4 sm:w-5 sm:h-5" /> },
    { id: 'notebook-lm', label: 'Notebook LM', icon: <Library className="w-4 h-4 sm:w-5 sm:h-5" /> },
    { id: 'code-lab', label: 'Code Lab', icon: <Code className="w-4 h-4 sm:w-5 sm:h-5" /> },
    { id: 'lingua-sphere', label: 'Lingua Sphere', icon: <Globe className="w-4 h-4 sm:w-5 sm:h-5" /> },
    { id: 'audio-studio', label: 'Audio Studio', icon: <Headphones className="w-4 h-4 sm:w-5 sm:h-5" /> },
  ];

  useEffect(() => {
    localStorage.setItem('edusphere_chat_history', JSON.stringify(messages));
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async (e?: React.FormEvent, customInput?: string) => {
    if (e) e.preventDefault();
    const finalInput = customInput || input;
    if (!finalInput.trim() && !fileBase64) return;
    if (isLoading) return;

    const userMsg: ChatMessage = { 
        id: Date.now().toString(), 
        role: 'user', 
        text: finalInput, 
        timestamp: new Date(),
        attachmentType: fileBase64 ? 'image' : undefined,
        attachmentUrl: fileBase64 || undefined
    };
    setMessages(prev => [...prev, userMsg]);
    if (!customInput) setInput('');
    setFile(null);
    setFileBase64(null);
    setIsLoading(true);

    try {
        const aiMsgId = (Date.now() + 1).toString();
        setMessages(prev => [...prev, { id: aiMsgId, role: 'ai', text: '', timestamp: new Date(), model: selectedModel }]);
        
        let accumulatedText = '';
        let accumulatedSources: { title: string; url: string }[] = [];
        
        if (searchMode) {
            const res = await performGlobalSearch(finalInput, language);
            accumulatedText = res.text;
            accumulatedSources = res.citations.map(c => ({ title: c.title, url: c.uri }));
            setMessages(prev => prev.map(m => m.id === aiMsgId ? { ...m, text: accumulatedText, sources: accumulatedSources } : m));
        } else if (mapsMode) {
            const res = await searchPlaces(finalInput, language);
            accumulatedText = res.text;
            accumulatedSources = res.places.map(p => ({ title: p.title, url: p.uri }));
            setMessages(prev => prev.map(m => m.id === aiMsgId ? { ...m, text: accumulatedText, sources: accumulatedSources } : m));
        } else if (finalInput.toLowerCase().startsWith('summarize:')) {
            const topic = finalInput.replace(/^summarize:\s*/i, '');
            const summary = await summarizeTopic(topic, language);
            accumulatedText = summary;
            setMessages(prev => prev.map(m => m.id === aiMsgId ? { ...m, text: accumulatedText } : m));
        } else {
            // Construct Memory Context (Last 3 turns)
            const recentHistory = messages.slice(-6).map(m => `${m.role === 'user' ? 'User' : 'AI'}: ${m.text}`).join('\n');
            const contextPrompt = `
            Previous Context:
            ${recentHistory}
            
            Current User Request: ${finalInput}
            ${fileBase64 ? '(User has uploaded an image for context)' : ''}
            
            ${getLangInstruction(language)}. 
            Provide a structured, deep academic response. Use emojis.
            CRITICAL: Keep simple answers extremely short and concise (one or two sentences) unless the user specifically asks for detail.
            `;

            const iterator = streamGeminiResponse(contextPrompt, selectedModel, true); // Search enabled by default for Gemini-like feel
            for await (const chunk of iterator) {
                accumulatedText += chunk.text;
                if (chunk.sources && chunk.sources.length > 0) {
                    // Deduplicate sources
                    const newSources = [...accumulatedSources];
                    chunk.sources.forEach(s => {
                        if (!newSources.some(ns => ns.url === s.url)) {
                            newSources.push(s);
                        }
                    });
                    accumulatedSources = newSources;
                }
                setMessages(prev => prev.map(m => m.id === aiMsgId ? { ...m, text: accumulatedText, sources: accumulatedSources } : m));
            }
        }
    } catch (e: any) { 
        console.error(e); 
        if (e.message?.includes("entity was not found")) {
            setHasApiKey(false);
            alert("API Key session expired. Please select your API key again.");
        }
        setMessages(prev => [...prev, { id: Date.now().toString(), role: 'ai', text: '❌ Error: The AI tutor is currently offline. Please try again later.', timestamp: new Date() }]);
    } finally { 
        setIsLoading(false); 
    }
  };

  const handleOpenKeySelector = async () => {
    if (window.aistudio) {
        await window.aistudio.openSelectKey();
        setHasApiKey(true);
    }
  };

  const handleVoiceInput = () => {
    if (!('webkitSpeechRecognition' in window)) {
        alert("Speech recognition not supported in this browser.");
        return;
    }
    
    const recognition = new (window as any).webkitSpeechRecognition();
    recognition.lang = language === 'hi' ? 'hi-IN' : 'en-US';
    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInput(transcript);
    };
    recognition.start();
  };

  const handleTTS = async (text: string) => {
    const audioData = await generateSpeech(text, 'Zephyr');
    if (audioData) {
        const audio = new Audio(`data:audio/mp3;base64,${audioData}`);
        audio.play();
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
        setFile(file);
        const reader = new FileReader();
        reader.onloadend = () => {
            setFileBase64(reader.result as string);
        };
        reader.readAsDataURL(file);
    }
  };

  const handleGenerateVideo = async () => {
    if (!videoPrompt.trim() || isGeneratingVideo) return;
    
    setIsGeneratingVideo(true);
    setShowVideoModal(false);
    
    const videoMsgId = Date.now().toString();
    const placeholderMsg: ChatMessage = { 
        id: videoMsgId, 
        role: 'ai', 
        text: `🎬 Visualizing: **${videoPrompt}**...`, 
        timestamp: new Date(),
        attachmentType: 'video' 
    };
    setMessages(prev => [...prev, placeholderMsg]);

    try {
        const videoUrl = await generateVideo(videoPrompt);
        if (videoUrl) {
            setMessages(prev => prev.map(m => m.id === videoMsgId ? { 
                ...m, 
                text: `✅ Video rendering complete for: **${videoPrompt}**`, 
                attachmentUrl: videoUrl 
            } : m));
        } else {
            throw new Error("Empty URL returned");
        }
    } catch (error) {
        setMessages(prev => prev.map(m => m.id === videoMsgId ? { 
            ...m, 
            text: "⚠️ Failed to generate cinematic video. Please try a simpler prompt.", 
            attachmentType: undefined 
        } : m));
    } finally {
        setIsGeneratingVideo(false);
        setVideoPrompt('');
    }
  };

  const handleGenerateImage = async () => {
    if (!imagePrompt.trim() || isGeneratingImage) return;
    
    setIsGeneratingImage(true);
    setShowImageModal(false);
    
    const imageMsgId = Date.now().toString();
    const placeholderMsg: ChatMessage = { 
        id: imageMsgId, 
        role: 'ai', 
        text: `🎨 Generating image for: **${imagePrompt}**...`, 
        timestamp: new Date(),
        attachmentType: 'image' 
    };
    setMessages(prev => [...prev, placeholderMsg]);

    try {
        const imageUrl = await generateImage(imagePrompt);
        if (imageUrl) {
            setMessages(prev => prev.map(m => m.id === imageMsgId ? { 
                ...m, 
                text: `✅ Image created for: **${imagePrompt}**`, 
                attachmentUrl: imageUrl 
            } : m));
        } else {
            throw new Error("Failed to generate image");
        }
    } catch (error) {
        setMessages(prev => prev.map(m => m.id === imageMsgId ? { 
            ...m, 
            text: "⚠️ Failed to generate image. Try another description.", 
            attachmentType: undefined 
        } : m));
    } finally {
        setIsGeneratingImage(false);
        setImagePrompt('');
    }
  };

  const clearHistory = () => {
    if (confirm("Clear all chat history?")) {
        setMessages([]);
        localStorage.removeItem('edusphere_chat_history');
    }
  };

  return (
    <div className="flex h-full bg-slate-50 overflow-hidden animate-in zoom-in-95 duration-700 relative">
      {/* Sidebar for Desktop */}
      <div className="hidden md:flex flex-col w-64 border-r border-slate-200 bg-white shadow-sm z-20">
        <div className="p-6 border-b border-slate-100">
            <h2 className="font-black text-slate-900 tracking-tight text-xl flex items-center gap-2">
                <Bot className="w-6 h-6 text-indigo-600" />
                AI Scholar
            </h2>
            <p className="text-[10px] text-slate-400 font-black tracking-widest uppercase mt-1">Multi-Modal Suite</p>
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
            {tabs.map(tab => (
                <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl font-bold text-sm transition-all ${activeTab === tab.id ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200' : 'text-slate-600 hover:bg-slate-50 hover:text-indigo-600'}`}
                >
                    {tab.icon}
                    {tab.label}
                </button>
            ))}
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-full relative overflow-hidden">
        {activeTab === 'chat' ? (
            <div className="flex flex-col h-full bg-white relative">
              {/* Background Decoration */}
              <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-indigo-500/5 blur-[150px] pointer-events-none" />
              <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-purple-500/5 blur-[150px] pointer-events-none" />

      {/* Header */}
      <div className="bg-white/80 backdrop-blur-2xl px-4 sm:px-10 py-4 sm:py-6 flex justify-between items-center border-b border-slate-100 z-30">
        <div className="flex items-center gap-3 sm:gap-6">
          <div className="relative">
            <div className="w-10 h-10 sm:w-14 h-14 rounded-xl sm:rounded-[1.5rem] bg-gradient-to-br from-indigo-600 to-violet-700 flex items-center justify-center text-white shadow-2xl shadow-indigo-300">
                <Bot className="w-5 h-5 sm:w-7 sm:h-7" />
            </div>
            <div className="absolute -bottom-1 -right-1 w-3 h-3 sm:w-4 sm:h-4 bg-emerald-500 border-2 sm:border-4 border-white rounded-full" />
          </div>
          <div className="relative">
            <button 
                onClick={() => setShowModelSelector(!showModelSelector)}
                className="flex items-center gap-2 hover:bg-slate-50 p-1 rounded-lg transition-colors group"
            >
                <h2 className="font-black text-slate-900 tracking-tight text-sm sm:text-xl">AI Scholar Assistant 🤖</h2>
                <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform ${showModelSelector ? 'rotate-180' : ''}`} />
            </button>
            
            {showModelSelector && (
                <div className="absolute top-full left-0 mt-2 w-64 bg-white rounded-2xl shadow-2xl border border-slate-100 p-2 z-50 animate-in fade-in slide-in-from-top-2">
                    {[
                        { id: 'gemini-3-flash-preview', label: 'Gemini 3 Flash', desc: 'Fast & efficient' },
                        { id: 'gemini-3.1-pro-preview', label: 'Gemini 3.1 Pro', desc: 'Complex reasoning', premium: true },
                        { id: 'gemini-2.5-flash', label: 'Gemini 2.5 Flash', desc: 'Balanced performance' },
                    ].map(m => (
                        <button
                            key={m.id}
                            onClick={() => { setSelectedModel(m.id as GeminiModel); setShowModelSelector(false); }}
                            className={`w-full text-left p-3 rounded-xl transition-all ${selectedModel === m.id ? 'bg-indigo-50 text-indigo-600' : 'hover:bg-slate-50 text-slate-600'}`}
                        >
                            <div className="flex items-center justify-between">
                                <p className="font-black text-sm">{m.label}</p>
                                {m.premium && <Sparkles className="w-3 h-3 text-amber-500" />}
                            </div>
                            <p className="text-[10px] font-medium opacity-60">{m.desc}</p>
                        </button>
                    ))}
                    <div className="mt-2 pt-2 border-t border-slate-50">
                        <button 
                            onClick={handleOpenKeySelector}
                            className="w-full flex items-center gap-2 p-3 rounded-xl hover:bg-slate-50 text-slate-400 transition-all"
                        >
                            <Key className={`w-4 h-4 ${hasApiKey ? 'text-emerald-500' : ''}`} />
                            <span className="text-[10px] font-black uppercase tracking-widest">{hasApiKey ? 'API Key Active' : 'Select API Key'}</span>
                        </button>
                    </div>
                </div>
            )}
            
            <div className="flex items-center gap-2 sm:gap-3">
                <span className="text-[8px] sm:text-[10px] text-slate-400 font-black tracking-widest uppercase">{selectedModel.split('-')[1]}</span>
                <span className="w-1 h-1 bg-slate-200 rounded-full" />
                <span className="text-[8px] sm:text-[10px] text-indigo-500 font-bold uppercase">{isLoading ? 'Synthesizing...' : 'Ready'}</span>
            </div>
          </div>
        </div>
        <div className="flex gap-1 sm:gap-2">
            <button onClick={() => setShowImageModal(true)} className="p-2 sm:p-3 bg-white border border-slate-100 text-slate-400 hover:text-emerald-600 rounded-xl sm:rounded-2xl transition-all shadow-sm" title="Generate AI Image">
                <ImageIcon className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
            <button onClick={() => setShowVideoModal(true)} className="p-2 sm:p-3 bg-white border border-slate-100 text-slate-400 hover:text-indigo-600 rounded-xl sm:rounded-2xl transition-all shadow-sm" title="Generate AI Video">
                <Video className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
            <div className="w-px h-8 sm:h-10 bg-slate-100 mx-1 sm:mx-2" />
            <button onClick={clearHistory} className="p-2 sm:p-3 bg-white border border-slate-100 text-slate-300 hover:text-rose-500 rounded-xl sm:rounded-2xl transition-all shadow-sm" title="Clear History">
                <Trash2 className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 sm:px-10 py-6 sm:py-8 space-y-8 sm:space-y-10 custom-scrollbar scroll-smooth">
        {messages.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-center p-4 sm:p-12 max-w-3xl mx-auto">
                <div className="w-20 h-20 sm:w-24 sm:h-24 bg-white rounded-full flex items-center justify-center mb-6 shadow-xl shadow-indigo-100/50 border border-slate-100">
                    <Bot className="w-10 h-10 sm:w-12 sm:h-12 text-indigo-600" />
                </div>
                <h3 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight mb-4">How can I help you learn today?</h3>
                <p className="text-slate-500 font-medium text-base sm:text-lg mb-8 sm:mb-12">Ask a question, search the web, or generate visual content.</p>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4 w-full">
                    {[
                        { icon: <Search className="w-5 h-5 text-blue-500" />, text: "Search latest news", mode: 'search' },
                        { icon: <MapPin className="w-5 h-5 text-emerald-500" />, text: "Find historical places", mode: 'maps' },
                        { icon: <MessageSquare className="w-5 h-5 text-indigo-500" />, text: "Explain Quantum Physics", mode: 'chat' },
                        { icon: <ImageIcon className="w-5 h-5 text-purple-500" />, text: "Generate a diagram", mode: 'image' },
                        { icon: <Calendar className="w-5 h-5 text-orange-500" />, text: "Create Study Plan", mode: 'plan' },
                        { icon: <FileText className="w-5 h-5 text-rose-500" />, text: "Summarize Topic", mode: 'summarize' }
                    ].map(item => (
                        <button 
                            key={item.text} 
                            onClick={() => {
                                if (item.mode === 'search') setSearchMode(true);
                                if (item.mode === 'maps') setMapsMode(true);
                                if (item.mode === 'image') { setShowImageModal(true); setImagePrompt(item.text); return; }
                                if (item.mode === 'plan') { navigate('/dashboard/study-planner'); return; }
                                if (item.mode === 'summarize') { setInput('Summarize: '); return; }
                                handleSend(undefined, item.text);
                            }} 
                            className="p-4 bg-white border border-slate-200 rounded-2xl hover:border-indigo-300 hover:shadow-md transition-all flex items-center gap-4 text-left group"
                        >
                            <div className="p-2 bg-slate-50 rounded-xl group-hover:scale-110 transition-transform">{item.icon}</div>
                            <span className="font-semibold text-slate-700 text-sm sm:text-base">{item.text}</span>
                        </button>
                    ))}
                </div>
            </div>
        )}

        {messages.map((msg, idx) => (
          <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-4 duration-500`}>
            <div className={`flex gap-3 max-w-[95%] sm:max-w-[85%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                {/* Avatar */}
                <div className="shrink-0 mt-auto mb-5 hidden sm:block">
                    {msg.role === 'user' ? (
                        <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold text-xs border border-indigo-200">You</div>
                    ) : (
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-600 to-violet-700 flex items-center justify-center text-white shadow-md">
                            <Bot className="w-4 h-4" />
                        </div>
                    )}
                </div>

                <div className="flex flex-col gap-1 min-w-0">
                    <div className={`
                        p-4 sm:p-5 rounded-3xl shadow-sm relative group transition-all
                        ${msg.role === 'user' 
                            ? 'bg-indigo-600 text-white rounded-br-sm' 
                            : 'bg-white text-slate-800 border border-slate-200 rounded-bl-sm'}
                    `}>
                        <RichText text={msg.text} isUser={msg.role === 'user'} />
                        
                        {msg.sources && msg.sources.length > 0 && (
                            <div className="mt-4 pt-4 border-t border-slate-100/20">
                                <p className={`text-[10px] font-black uppercase tracking-widest mb-2 flex items-center gap-2 ${msg.role === 'user' ? 'text-indigo-200' : 'text-slate-400'}`}>
                                    <Search className="w-3 h-3" /> Sources
                                </p>
                                <div className="flex flex-wrap gap-2">
                                    {msg.sources.map((source, sIdx) => (
                                        <a 
                                            key={sIdx}
                                            href={source.url}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold transition-all max-w-full
                                                ${msg.role === 'user' 
                                                    ? 'bg-indigo-500/30 hover:bg-indigo-500/50 text-white border border-indigo-400/30' 
                                                    : 'bg-slate-50 hover:bg-indigo-50 border border-slate-200 hover:border-indigo-200 text-slate-600 hover:text-indigo-600'}`}
                                        >
                                            <Globe className="w-3 h-3 shrink-0" />
                                            <span className="truncate">{source.title}</span>
                                            <ExternalLink className="w-2 h-2 shrink-0" />
                                        </a>
                                    ))}
                                </div>
                            </div>
                        )}
                        
                        {msg.attachmentType && (
                            <div className="mt-4 overflow-hidden rounded-2xl bg-slate-900 border border-slate-800 min-h-[150px] flex items-center justify-center shadow-inner">
                                {msg.attachmentUrl ? (
                                    msg.attachmentType === 'video' ? (
                                        <video controls className="w-full aspect-video">
                                            <source src={msg.attachmentUrl} type="video/mp4" />
                                        </video>
                                    ) : (
                                        <img src={msg.attachmentUrl} alt="AI Content" className="w-full h-full object-contain" />
                                    )
                                ) : (
                                    <div className="flex flex-col items-center gap-3 p-8 text-center">
                                        <Loader2 className="w-8 h-8 text-indigo-400 animate-spin" />
                                        <p className="text-[10px] font-black text-white uppercase tracking-widest">Generating...</p>
                                    </div>
                                )}
                            </div>
                        )}

                        {/* Bubble Actions */}
                        <div className={`
                            absolute -bottom-10 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1.5
                            ${msg.role === 'user' ? 'right-2' : 'left-2'}
                        `}>
                            <button onClick={() => handleTTS(msg.text)} className="p-1.5 bg-white border border-slate-200 rounded-lg text-slate-400 hover:text-indigo-600 shadow-sm transition-all hover:scale-105">
                                <Volume2 className="w-3.5 h-3.5" />
                            </button>
                            <button onClick={() => navigator.clipboard.writeText(msg.text)} className="p-1.5 bg-white border border-slate-200 rounded-lg text-slate-400 hover:text-indigo-600 shadow-sm transition-all hover:scale-105">
                                <Copy className="w-3.5 h-3.5" />
                            </button>
                        </div>
                    </div>
                    <span className={`text-[9px] font-bold uppercase tracking-wider text-slate-400 mt-1 ${msg.role === 'user' ? 'text-right mr-1' : 'text-left ml-1'}`}>
                        {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                </div>
            </div>
          </div>
        ))}

        
        {isLoading && (
            <div className="flex justify-start animate-in fade-in slide-in-from-left-6 duration-500">
                <div className="bg-white border border-slate-100 p-6 rounded-[2.5rem] rounded-tl-none flex flex-col gap-4 shadow-sm min-w-[200px]">
                    <div className="flex items-center gap-3">
                        <div className="relative">
                            <div className="w-8 h-8 bg-indigo-50 rounded-full flex items-center justify-center">
                                <Bot className="w-4 h-4 text-indigo-600 animate-pulse" />
                            </div>
                            <div className="absolute -bottom-1 -right-1 w-2.5 h-2.5 bg-emerald-500 border-2 border-white rounded-full" />
                        </div>
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Scholar is thinking...</span>
                    </div>
                    <div className="flex gap-1.5">
                        <div className="w-2 h-2 bg-indigo-600 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                        <div className="w-2 h-2 bg-indigo-600 rounded-full animate-bounce" style={{ animationDelay: '200ms' }} />
                        <div className="w-2 h-2 bg-indigo-600 rounded-full animate-bounce" style={{ animationDelay: '400ms' }} />
                    </div>
                </div>
            </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="px-4 sm:px-10 pb-6 sm:pb-8 pt-2 bg-gradient-to-t from-slate-50 via-slate-50 to-transparent relative z-10">
         <div className="max-w-4xl mx-auto relative">
             {file && (
                <div className="absolute -top-16 left-4 bg-white p-2 sm:p-3 rounded-2xl border border-slate-200 shadow-lg flex items-center gap-3 animate-in slide-in-from-bottom-4">
                    <div className="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600">
                        <Paperclip className="w-5 h-5" />
                    </div>
                    <div className="pr-4">
                        <p className="text-xs font-bold text-slate-900 truncate max-w-[150px]">{file.name}</p>
                        <button type="button" onClick={() => { setFile(null); setFileBase64(null); }} className="text-[10px] font-bold text-rose-500 hover:text-rose-600 uppercase tracking-wider">Remove</button>
                    </div>
                </div>
             )}

             <form onSubmit={handleSend} className="flex flex-col bg-white rounded-[2rem] shadow-xl shadow-slate-200/50 border border-slate-200 focus-within:border-indigo-300 focus-within:ring-4 focus-within:ring-indigo-50 transition-all">
                <div className="flex items-start px-4 pt-4 pb-2">
                    <textarea 
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
                        placeholder={searchMode ? "Search the web..." : mapsMode ? "Find places..." : "Message AI Scholar..."}
                        className="w-full bg-transparent focus:outline-none text-slate-700 placeholder-slate-400 text-base sm:text-lg resize-none min-h-[44px] max-h-32 custom-scrollbar"
                        rows={1}
                    />
                </div>
                <div className="flex items-center justify-between px-3 pb-3">
                    <div className="flex items-center gap-1">
                        <button 
                            type="button" 
                            onClick={() => fileInputRef.current?.click()}
                            className="p-2.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-full transition-colors"
                            title="Attach Image"
                        >
                            <Paperclip className="w-5 h-5" />
                        </button>
                        <input type="file" ref={fileInputRef} onChange={handleFileSelect} className="hidden" accept="image/*" />
                        
                        <button 
                            type="button" 
                            onClick={handleVoiceInput}
                            className={`p-2.5 transition-colors rounded-full ${isListening ? 'bg-rose-100 text-rose-600 animate-pulse' : 'text-slate-400 hover:text-indigo-600 hover:bg-indigo-50'}`}
                            title="Voice Input"
                        >
                            <Mic className="w-5 h-5" />
                        </button>
                        
                        <div className="w-px h-6 bg-slate-200 mx-1" />
                        
                        <button 
                            type="button"
                            onClick={() => setSearchMode(!searchMode)} 
                            className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 ${searchMode ? 'bg-blue-100 text-blue-700' : 'text-slate-500 hover:bg-slate-100'}`}
                        >
                            <Search className="w-3.5 h-3.5" /> Web
                        </button>
                        <button 
                            type="button"
                            onClick={() => setMapsMode(!mapsMode)} 
                            className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all flex items-center gap-1.5 ${mapsMode ? 'bg-emerald-100 text-emerald-700' : 'text-slate-500 hover:bg-slate-100'}`}
                        >
                            <MapPin className="w-3.5 h-3.5" /> Places
                        </button>
                    </div>
                    
                    <button 
                        type="submit" 
                        disabled={(!input.trim() && !fileBase64) || isLoading} 
                        className={`
                            p-3 rounded-full text-white transition-all active:scale-95 disabled:opacity-50
                            ${(input.trim() || fileBase64) ? 'bg-indigo-600 hover:bg-indigo-700 shadow-md shadow-indigo-200' : 'bg-slate-200'}
                        `}
                    >
                        <Send className="w-5 h-5" />
                    </button>
                </div>
             </form>
             <div className="mt-3 text-center">
                 <p className="text-[10px] text-slate-400 font-medium">AI Scholar can make mistakes. Consider verifying important information.</p>
             </div>
         </div>
      </div>

      {/* Video Generation Modal */}
      {showVideoModal && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 sm:p-6 bg-slate-900/60 backdrop-blur-xl animate-in fade-in duration-300">
            <div className="bg-white rounded-[2rem] sm:rounded-[4rem] w-full max-w-2xl p-6 sm:p-12 shadow-[0_50px_100px_-20px_rgba(0,0,0,0.5)] relative border border-white max-h-[90vh] overflow-y-auto no-scrollbar">
                <button onClick={() => setShowVideoModal(false)} className="absolute top-6 sm:top-10 right-6 sm:right-10 p-2 sm:p-4 hover:bg-slate-100 rounded-full transition-colors text-slate-300">
                    <X className="w-6 h-6 sm:w-8 sm:h-8" />
                </button>
                
                <div className="mb-6 sm:mb-10 space-y-2 sm:space-y-4">
                    <div className="bg-indigo-100 w-16 h-16 sm:w-20 sm:h-20 rounded-2xl sm:rounded-[2rem] flex items-center justify-center mb-4 sm:mb-6">
                        <Video className="w-8 h-8 sm:w-10 sm:h-10 text-indigo-600" />
                    </div>
                    <h3 className="text-2xl sm:text-4xl font-black text-slate-900 tracking-tight">Cinematic Visualization 🎥</h3>
                    <p className="text-slate-500 text-sm sm:text-lg font-medium leading-relaxed">Describe a complex concept, and our AI will render a high-fidelity educational video for you.</p>
                </div>

                <div className="space-y-6 sm:space-y-8">
                    <div className="bg-amber-50 p-4 sm:p-6 rounded-2xl sm:rounded-[2rem] border border-amber-100 text-[10px] sm:text-xs text-amber-800 font-black uppercase tracking-widest flex gap-3 sm:gap-4">
                        <Info className="w-5 h-5 sm:w-6 sm:h-6 shrink-0" />
                        <span>Requires a selected API Key from a paid project.</span>
                    </div>

                    <div className="relative">
                        <textarea 
                            value={videoPrompt}
                            onChange={(e) => setVideoPrompt(e.target.value)}
                            placeholder="e.g. A 3D simulation of a black hole..."
                            className="w-full p-4 sm:p-8 rounded-2xl sm:rounded-[2.5rem] border border-slate-100 bg-slate-50 focus:bg-white focus:ring-8 focus:ring-indigo-50 outline-none h-32 sm:h-48 resize-none text-sm sm:text-lg leading-relaxed transition-all"
                        />
                    </div>

                    <button 
                        onClick={handleGenerateVideo}
                        disabled={!videoPrompt.trim() || isGeneratingVideo}
                        className="w-full bg-slate-900 text-white py-4 sm:py-6 rounded-2xl sm:rounded-[2.5rem] font-black text-lg sm:text-xl flex items-center justify-center gap-3 sm:gap-4 hover:bg-slate-800 transition-all shadow-2xl disabled:opacity-50 active:scale-95"
                    >
                        {isGeneratingVideo ? <Loader2 className="w-6 h-6 sm:w-8 sm:h-8 animate-spin text-indigo-400" /> : <Sparkles className="w-6 h-6 sm:w-8 sm:h-8 text-indigo-400" />}
                        Generate Visualization
                    </button>
                </div>
            </div>
        </div>
      )}

      {/* Image Generation Modal */}
      {showImageModal && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 sm:p-6 bg-slate-900/60 backdrop-blur-xl animate-in fade-in duration-300">
            <div className="bg-white rounded-[2rem] sm:rounded-[4rem] w-full max-w-2xl p-6 sm:p-12 shadow-[0_50px_100px_-20px_rgba(0,0,0,0.5)] relative border border-white max-h-[90vh] overflow-y-auto no-scrollbar">
                <button onClick={() => setShowImageModal(false)} className="absolute top-6 sm:top-10 right-6 sm:right-10 p-2 sm:p-4 hover:bg-slate-100 rounded-full transition-colors text-slate-300">
                    <X className="w-6 h-6 sm:w-8 sm:h-8" />
                </button>
                
                <div className="mb-6 sm:mb-10 space-y-2 sm:space-y-4">
                    <div className="bg-emerald-100 w-16 h-16 sm:w-20 sm:h-20 rounded-2xl sm:rounded-[2rem] flex items-center justify-center mb-4 sm:mb-6">
                        <ImageIcon className="w-8 h-8 sm:w-10 sm:h-10 text-emerald-600" />
                    </div>
                    <h3 className="text-2xl sm:text-4xl font-black text-slate-900 tracking-tight">AI Image Studio 🎨</h3>
                    <p className="text-slate-500 text-sm sm:text-lg font-medium leading-relaxed">Create diagrams, illustrations, or artistic representations of any topic instantly.</p>
                </div>

                <div className="space-y-6 sm:space-y-8">
                    <div className="relative">
                        <textarea 
                            value={imagePrompt}
                            onChange={(e) => setImagePrompt(e.target.value)}
                            placeholder="e.g. A detailed scientific diagram..."
                            className="w-full p-4 sm:p-8 rounded-2xl sm:rounded-[2.5rem] border border-slate-100 bg-slate-50 focus:bg-white focus:ring-8 focus:ring-emerald-50 outline-none h-32 sm:h-48 resize-none text-sm sm:text-lg leading-relaxed transition-all"
                        />
                    </div>

                    <button 
                        onClick={handleGenerateImage}
                        disabled={!imagePrompt.trim() || isGeneratingImage}
                        className="w-full bg-emerald-600 text-white py-4 sm:py-6 rounded-2xl sm:rounded-[2.5rem] font-black text-lg sm:text-xl flex items-center justify-center gap-3 sm:gap-4 hover:bg-emerald-700 transition-all shadow-2xl disabled:opacity-50 active:scale-95"
                    >
                        {isGeneratingImage ? <Loader2 className="w-6 h-6 sm:w-8 sm:h-8 animate-spin text-white" /> : <ImageIcon className="w-6 h-6 sm:w-8 sm:h-8 text-emerald-200" />}
                        Generate Image
                    </button>
                </div>
            </div>
        </div>
      )}
            </div>
        ) : (
            <div className="flex-1 overflow-y-auto w-full h-full p-4 md:p-8">
                {activeTab === 'study-buddy' && <StudyBuddy />}
                {activeTab === 'live-tutor' && <LiveTutor />}
                {activeTab === 'documind' && <DocuMind />}
                {activeTab === 'notebook-lm' && <NotebookLM />}
                {activeTab === 'code-lab' && <CodeLab />}
                {activeTab === 'lingua-sphere' && <LinguaSphere />}
                {activeTab === 'audio-studio' && <AudioStudio />}
            </div>
        )}

        {/* Bottom Nav for Mobile */}
        <div className="md:hidden flex overflow-x-auto border-t border-slate-100 bg-white/80 backdrop-blur-xl p-2 gap-1 z-20 no-scrollbar shrink-0">
            {tabs.map(tab => (
                <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex flex-col items-center justify-center min-w-[64px] p-1.5 rounded-xl transition-all ${activeTab === tab.id ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-200' : 'text-slate-400 hover:text-slate-600'}`}
                >
                    <div className={`${activeTab === tab.id ? 'scale-110' : ''} transition-transform`}>
                        {tab.icon}
                    </div>
                    <span className="text-[8px] font-black uppercase tracking-widest mt-1 text-center leading-tight">{tab.label.split(' ')[0]}</span>
                </button>
            ))}
        </div>
      </div>
    </div>
  );
};
