
import React, { useState, useEffect, useRef } from 'react';
import { useAppContext } from '../App';
import { getGeminiResponse } from '../services/geminiService';
import { dbService } from '../services/dbService';
import { SUBJECTS } from '../constants';
import { ChatMessage, Subject } from '../types';

export const DoubtChat: React.FC = () => {
    const { language } = useAppContext();
    const [messages, setMessages] = useState<ChatMessage[]>(() => {
        const saved = localStorage.getItem('edusphere_doubt_history');
        return saved ? JSON.parse(saved) : [];
    });
    const [input, setInput] = useState('');
    const [loading, setLoading] = useState(false);
    const scrollRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        localStorage.setItem('edusphere_doubt_history', JSON.stringify(messages));
        scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const handleSend = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!input.trim() || loading) return;

        const userMsg: ChatMessage = { 
            id: Date.now().toString(), 
            role: 'user', 
            text: input, 
            timestamp: new Date() 
        };

        setMessages(prev => [...prev, userMsg]);
        setInput('');
        setLoading(true);

        try {
            const aiText = await getGeminiResponse(`User Doubt: ${input}`, language);
            const aiMsg: ChatMessage = { 
                id: (Date.now() + 1).toString(), 
                role: 'ai', 
                text: aiText, 
                timestamp: new Date() 
            };
            setMessages(prev => [...prev, aiMsg]);
        } catch (error) {
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="flex h-screen flex-col bg-white overflow-hidden animate-in fade-in duration-500 relative">
            {/* Header */}
            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-white sticky top-0 z-10 shadow-sm">
                <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-indigo-600 flex items-center justify-center text-white shadow-lg">
                        <span className="text-2xl">🤖</span>
                    </div>
                    <div>
                        <h2 className="text-xl font-black text-slate-800">AI Doubt Solver</h2>
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Instant Academic Support</p>
                    </div>
                </div>
                <button onClick={() => { if(confirm("Clear history?")) { setMessages([]); localStorage.removeItem('edusphere_doubt_history'); } }} className="text-[10px] font-black text-rose-500 uppercase tracking-widest bg-rose-50 px-4 py-2 rounded-xl hover:bg-rose-100 transition-colors">Reset Chat</button>
            </div>

            {/* Chat Area */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-8 space-y-6 sm:space-y-8 bg-slate-50/50 custom-scrollbar scroll-smooth">
                {messages.length === 0 && (
                    <div className="h-full flex flex-col items-center justify-center text-center p-6 sm:p-12 max-w-2xl mx-auto">
                        <div className="w-20 h-20 sm:w-24 sm:h-24 bg-white rounded-full shadow-xl shadow-indigo-100/50 border border-slate-100 flex items-center justify-center text-4xl sm:text-5xl mb-6">💬</div>
                        <h3 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight mb-4">Ask Anything!</h3>
                        <p className="text-slate-500 font-medium text-base sm:text-lg">I'm your 24/7 academic assistant. No subject filters, just pure knowledge.</p>
                    </div>
                )}
                
                {messages.map((msg, idx) => (
                    <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-4 duration-500`}>
                        <div className={`flex gap-3 max-w-[95%] sm:max-w-[85%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                            {/* Avatar */}
                            <div className="shrink-0 mt-auto mb-5 hidden sm:block">
                                {msg.role === 'user' ? (
                                    <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold text-xs border border-indigo-200">You</div>
                                ) : (
                                    <div className="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center text-white shadow-md text-sm">🤖</div>
                                )}
                            </div>

                            <div className="flex flex-col gap-1 min-w-0">
                                <div className={`
                                    p-4 sm:p-5 rounded-3xl shadow-sm relative group transition-all
                                    ${msg.role === 'user' 
                                        ? 'bg-indigo-600 text-white rounded-br-sm' 
                                        : 'bg-white text-slate-800 border border-slate-200 rounded-bl-sm'}
                                `}>
                                    <p className="text-sm sm:text-base font-medium leading-relaxed whitespace-pre-line">{msg.text}</p>
                                </div>
                                <span className={`text-[9px] font-bold uppercase tracking-wider text-slate-400 mt-1 ${msg.role === 'user' ? 'text-right mr-1' : 'text-left ml-1'}`}>
                                    {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                </span>
                            </div>
                        </div>
                    </div>
                ))}
                {loading && (
                    <div className="flex justify-start animate-in fade-in slide-in-from-left-4 duration-500">
                        <div className="bg-white border border-slate-200 p-4 sm:p-5 rounded-3xl rounded-bl-sm flex items-center gap-3 shadow-sm ml-0 sm:ml-11">
                            <div className="flex gap-1.5">
                                <div className="w-2 h-2 bg-indigo-600 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                                <div className="w-2 h-2 bg-indigo-600 rounded-full animate-bounce" style={{ animationDelay: '200ms' }}></div>
                                <div className="w-2 h-2 bg-indigo-600 rounded-full animate-bounce" style={{ animationDelay: '400ms' }}></div>
                            </div>
                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Tutor is thinking...</span>
                        </div>
                    </div>
                )}
                <div ref={scrollRef} />
            </div>

            {/* Input Area */}
            <div className="px-4 sm:px-8 pb-6 sm:pb-8 pt-2 bg-gradient-to-t from-slate-50 via-slate-50 to-transparent relative z-10">
                <form onSubmit={handleSend} className="flex gap-2 sm:gap-4 max-w-4xl mx-auto bg-white p-2 sm:p-3 rounded-[2rem] shadow-xl shadow-slate-200/50 border border-slate-200 focus-within:border-indigo-300 focus-within:ring-4 focus-within:ring-indigo-50 transition-all items-center">
                    <input
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        placeholder="Type your academic question here..."
                        className="flex-1 bg-transparent px-4 py-2 focus:outline-none font-medium text-base sm:text-lg text-slate-700 placeholder-slate-400"
                    />
                    <button
                        type="submit"
                        disabled={loading || !input.trim()}
                        className="bg-indigo-600 text-white p-3 sm:p-4 rounded-full shadow-md shadow-indigo-200 hover:bg-indigo-700 active:scale-95 disabled:opacity-50 disabled:bg-slate-200 transition-all flex items-center justify-center shrink-0"
                    >
                        <span className="text-xl sm:text-2xl leading-none">🚀</span>
                    </button>
                </form>
            </div>
        </div>
    );
};
